<?php
defined('BASEPATH') OR exit('No direct script access allowed');


$route['default_controller'] = 'admin';
$route['dashboard'] = 'pages/dashboard';
$route['admin'] = 'admin';
$route['test'] = 'Pages/test';
$route['404_override'] = '';
$route['translate_uri_dashes'] = TRUE;

?>