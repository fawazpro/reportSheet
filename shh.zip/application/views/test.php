<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Dashboard</title>
</head>

<body>
    <h1>Test</h1>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Alias repellendus nobis officiis vero provident laborum autem molestiae perspiciatis adipisci, nisi animi pariatur consequatur commodi cumque. Sint eius quae porro, earum a aspernatur ad itaque laborum recusandae est? Libero illo, numquam ullam odit magnam fugit voluptatibus vel odio repellendus blanditiis nisi.</p>

</body>

</html>